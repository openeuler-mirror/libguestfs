let libosinfo_db_path = "/usr/share/libosinfo/db"
