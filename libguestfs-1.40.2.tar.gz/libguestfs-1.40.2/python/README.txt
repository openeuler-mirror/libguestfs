libguestfs is a library and set of tools for accessing and modifying
virtual machine (VM) disk images.

This package contains the Python bindings for libguestfs.
