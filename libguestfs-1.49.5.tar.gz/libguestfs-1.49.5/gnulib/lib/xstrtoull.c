#define __strtol strtoull
#define __strtol_t unsigned long long int
#define __xstrtol xstrtoull
#define STRTOL_T_MINIMUM 0
#define STRTOL_T_MAXIMUM ULLONG_MAX
#include "xstrtol.c"
